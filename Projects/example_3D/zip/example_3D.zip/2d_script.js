(function(){
	var GL_ZERO=0x0;
	var GL_ONE=0x1;
	var GL_SRC_COLOR=0x0300;
	var GL_ONE_MINUS_SRC_COLOR=0x0301;
	var GL_SRC_ALPHA=0x0302;
	var GL_ONE_MINUS_SRC_ALPHA=0x0303;
	var GL_DST_ALPHA=0x0304;
	var GL_ONE_MINUS_DST_ALPHA=0x0305;
	var GL_DST_COLOR=0x0306;
	var GL_ONE_MINUS_DST_COLOR=0x0307;
	var GL_SRC_ALPHA_SATURATE=0x0308;
	var GL_CONSTANT_COLOR=0x8001;
	var GL_ONE_MINUS_CONSTANT_COLOR=0x8002;
	var GL_CONSTANT_ALPHA=0x8003;
	var GL_ONE_MINUS_CONSTANT_ALPHA=0x8004;
	/////////////////////////util
	isActionTriggered=function (actionname, params){
		if(params.expression==undefined || params.rotation==undefined)return false;
		switch (actionname){
			
			case "taimei":
				return params.expression[16] >= 0.4 || params.expression[17] >= 0.4 || params.expression[18] >= 0.4;
				break;

			case "taizuijiao_zuo":
				return params.expression[24] >= 0.4 || params.expression[28] >= 0.4;
				break;

			case "taizuijiao_you":
				return params.expression[23] >= 0.4 || params.expression[27] >= 0.4;
				break;

			case "nu":
				return params.expression[42] >= 0.5;
				break;

			case "zuixing_o":
				return params.expression[38] >= 0.4;
				break;

			case "zuixing_a":
				return params.expression[21] >= 0.3;
				break;

			case "zuixing_du":
				return params.expression[39] >= 0.5;
				break;

			case "zuixing_min":
				return params.expression[33] >= 0.5 || params.expression[34] >= 0.5;
				break;

			case "zuixing_guqi":
				return params.expression[43] >= 0.5;
				break;

			case "biyan_zuo":
				return params.expression[1] >= 0.5;
				break;

			case "biyan_you":
				return params.expression[0] >= 0.5;
				break;

			case "zhuantou_zuo":
				return params.rotation[1] >= 0.1;
				break;

			case "zhuantou_you":
				return params.rotation[1] >= 0.1;
				break;

			default:
				return false;
				break;
		}
	};
	//
	console.log("Platform:",FaceUnity.m_platform);
	
	var g_params={
		isAndroid: 0,
		isLandscape:0,
		rotationAngle:0,
		rotationTexAngle:0,
		matp:[1,0,0,1],
		hasmatp:0,
		rmode:0,
		isTracked:0,
	};
	/////////////////////////res
	var boards = JSON.parse(FaceUnity.ReadFromCurrentItem("2d_desc.json"));
	var bigtexjson = JSON.parse(FaceUnity.ReadFromCurrentItem("2d_bigtex_desc.json"));
	var s_eyes_shader=FaceUnity.ReadFromCurrentItem("2d_eyes.glsl");
	
	/*back#1ground_seg
	var model_v=FaceUnity.LoadNNModel("nn_v.json");
	var model_h=FaceUnity.LoadNNModel("nn_h.json");
	var base_color=new Float32Array([-122.675/255,-116.669/255,-104.008/255]);
	var s_visualize_shader=FaceUnity.ReadFromCurrentItem("visualize.glsl");
	var cur_rotation_mode=-1;
	var cnn_prob = new Array();
	var cnn_running_time_sum = 0.;
	var cnn_running_time_count = 0;
	//back#1ground_seg*/
	
	var bigtexcnt = 0;
	var bigtex = new Array();
	for(var i=0;i<bigtexjson["bigtexs"].length;i++){
		bigtex[bigtexcnt] = FaceUnity.LoadTexture(bigtexjson["bigtexs"][i],0);
		bigtexcnt++;
	}
	
	var arTex = new Array();
	var ar_meshs = boards.filter(function(board){return board.name.search("_ar")!=-1;});
	
	var boards = boards.filter(function(board){return board.name.search("_ar")==-1;});
	
	ar_meshs.forEach(function(armesh){arTex.push(FaceUnity.LoadTexture(armesh.path));});
	
	deepCopy =function(p, c){
		var c = c || {};
　　　　for (var i in p) {
　　　　　　if (typeof p[i] === 'object') {
　　　　　　　　c[i] = (p[i].constructor === Array) ? [] : {};
　　　　　　　　deepCopy(p[i], c[i]);
　　　　　　} else {
　　　　　　　　　c[i] = p[i];
　　　　　　}
　　　　}
　　　　return c;
　　}
	//define Mesh for render objects
	//constructor Mesh, board for 2d,drawcall for 3d,
	var Mesh = function(board, drawcall){
		if(board!=undefined){
			deepCopy(board,this);
			this.texture_frames_bk = deepCopy(board.texture_frames,[]);
			this.itemtype=2;
			if (this.name == "EyeL"||this.name == "EyeR") this.shader=s_eyes_shader;
		}else if(drawcall!=undefined){
			this.itemtype=3;
		}
		if(this.betriggered==undefined)this.isActive = true;
	}
	Mesh.prototype.reExtract=function (params){
		try{
			var w = params.w;
			var h = params.h; 
			if(g_params.isAndroid > 0.5){
				h=params.w;
				w=params.h;		
			}
			var ar_mat = [1,0,0,1];
			if(g_params.hasmatp<0.5){
				var rmode = FaceUnity.g_current_rmode!=undefined ? FaceUnity.g_current_rmode : g_params.rmode;
				if(g_params.isTracked < 0.5){
					if(g_params.isAndroid>0.5)rmode = 1;
					else rmode =0;
				}
				if(g_params.isAndroid && rmode%2==0){
					w=params.w;
					h=params.h;
				}
				if(!g_params.isAndroid && rmode%2==1){
					h=params.w;
					w=params.h;
				}
				var m =ar_mat;
				if(FaceUnity.GetARMat)m= FaceUnity.GetARMat();
				ar_mat = [m[0],m[1],m[2],m[3]];
				if(g_params.isTracked < 0.5 ){
					if(g_params.isAndroid>0.5)ar_mat = [0,1,-1,0];
					else ar_mat = [1,0,0,1];
				}
			}
			if(this.name.search("_fg")!=-1){//foreground item
				for (var j=0;j<this.texture_frames_bk.length;j++){
					var ww = this.texture_frames_bk[j].v[2];
					var hh = this.texture_frames_bk[j].v[5];
					var ratio = (w/380.0) < (h/672.0) ? (w/380.0) : (h/672.0);
					ww = ww * ratio;
					hh = hh * ratio;
					var rcx = this.texture_frames_bk[j].v[8];
					var rcy = 1-this.texture_frames_bk[j].v[11];
					var bx = - w/2 + rcx * w;
					var bh = -h/2 + rcy * h;
					var l = this.texture_frames_bk[j].v[0]* ratio;
					var r = this.texture_frames_bk[j].v[3]* ratio;
					var t = this.texture_frames_bk[j].v[1]* ratio;
					var b = this.texture_frames_bk[j].v[10]* ratio;
					this.texture_frames[j].v=[ bx + l, bh + t,params.focal_length,
													bx + r, bh + t,params.focal_length,
													bx + r, bh + b,params.focal_length,
													bx + l, bh + b,params.focal_length];
				}
				this.matp = ar_mat;
				if(g_params.hasmatp)this.matp = g_params.matp;
			}
			if(this.name.search("_fc")!=-1){//full screen items
				var isP = this.name[this.name.length-1]=='p';
				if(isP){//portrait
					if(g_params.isLandscape>0.5)this.isActive = false;
				}else{
					if(g_params.isLandscape<0.5)this.isActive = false;
				}
				var scalez = 1;
				if(this.name[this.name.length-2]=='g')scalez = (20000/params.focal_length);//fcbackground
				if(!isP){
					var tmp = w; w = h; h = tmp;
				}
				for (var j=0;j<this.texture_frames_bk.length;j++){
					this.texture_frames[j].v=[-scalez*w/2,scalez*h/2,scalez*params.focal_length,
												+scalez*w/2,scalez*h/2,scalez*params.focal_length,
												+scalez*w/2,-scalez*h/2,scalez*params.focal_length,
												-scalez*w/2,-scalez*h/2,scalez*params.focal_length];
				}
				this.matp = ar_mat;
				if(g_params.hasmatp)this.matp = g_params.matp;
			}
		}catch(err){
			console.log(err.stack)
		}
	};
	Mesh.prototype.recalUV = function(){
		var flip = g_params.rotationTexAngle < 0 ? 1 : 0;
		var rotationAngle = Math.abs(g_params.rotationTexAngle) % 360;
		var shiftcopy = 8;
		//ccw rotation
		if(Math.abs(rotationAngle-90)<0.01)shiftcopy = 10;
		if(Math.abs(rotationAngle-180)<0.01)shiftcopy = 12;
		if(Math.abs(rotationAngle-270)<0.01)shiftcopy = 14;
		//if(g_params.isLandscape)shiftcopy-=2;
		for (var j=0;j<this.texture_frames_bk.length;j++){
			for(var t =0;t<this.texture_frames_bk[j].vt.length;t++){
				this.texture_frames[j].vt[t] = this.texture_frames_bk[j].vt[(t+shiftcopy)%8]; 
			}
			if(flip){
				for(var i = 0;i<2;i++){
					var tmpx = this.texture_frames[j].vt[i*4+0];
					var tmpy = this.texture_frames[j].vt[i*4+1];
					this.texture_frames[j].vt[i*4+0] = this.texture_frames[j].vt[i*4+2];
					this.texture_frames[j].vt[i*4+1] = this.texture_frames[j].vt[i*4+3];
					this.texture_frames[j].vt[i*4+2] = tmpx;
					this.texture_frames[j].vt[i*4+3] = tmpy;
				}
			}
		}
	}
	Mesh.prototype.switchState = function(lst,now){
		if(this.betriggered)return;
		if(lst==0 && now==1){
			if(this.triggerstart=="newface")this.isActive = true;
			//console.log("switchState:",this.name,this.isActive);
		}
		if(lst==1 && now==0){
			if(this.triggerstart=="alwaysrender")this.isActive = true;
		}
		this.orientationChange();
	}
	Mesh.prototype.orientationChange = function(){
		var bisLandscape = g_params.isLandscape < 0.5 ? false : true;
		if(this.name.search("_fc")!=-1){
			this.isActive = bisLandscape == (this.name.search("_fcl")!=-1||this.name.search("_fcbgl")!=-1);
		}
	}
	Mesh.prototype.stopThis = function(now){
		//console.log("stopThis:",this.name);
		if(!this.triggered)return;
		this.triggered =0;
		this.frame_id = 0;
		this.last = now;
		this.activateNext();
		if(this.triggerstart=="newface"||this.triggerstart=="alwaysrender"){
			this.isActive = false;
		}	
	}
	Mesh.prototype.recursiveStop = function(now){
		this.stopThis(now);
		if(this.nodetype==3)return;
		for(var i = 0;i < this.childNodesRef.length;i++){
			this.childNodesRef[i].recursiveStop(now);
		}
	}
	Mesh.prototype.stop = function(now){
		if(this.nodetype==1){
			this.recursiveStop(now);
		}else{
			this.stopThis(now);
		}
	}
	Mesh.prototype.activateNext = function(){
		if(this.triggerNextNodesRef==undefined || this.triggerNextNodesRef.length==0)return;
		for(var idx in this.triggerNextNodesRef){
			this.triggerNextNodesRef[idx].isActive=true;
		}
	}
	Mesh.prototype.updateEvent=function(params,now){
		if(this.triggered){
			var elapse = now - this.last;
			this.frame_id = parseInt(elapse * this.fps / 1000);
			if(this.force_frame_id!=undefined && this.force_frame_id>=0)this.frame_id = this.force_frame_id;
		}
			
		if (this.name == "EyeL" && params.expression)this.uniforms={scale:1-params.expression[0]};
		if (this.name == "EyeR" && params.expression)this.uniforms={scale:1-params.expression[1]};
	}
	Mesh.prototype.triggerThis=function(now){
		this.triggered = 1;
		this.frame_id = 0;
		this.last = now;
		this.isActive = true;
		console.log("thriggerThis2d",this.name);
	}
	Mesh.prototype.triggerStartEvent=function(params,now,isNoneFace){
		if(this.triggered || !this.isActive || !(this.nodetype == 0 || this.nodetype == 1))return;
		if((!isNoneFace && (this.triggerstart=="newface" || (this.triggerstart=="faceaction" && isActionTriggered(this.startaction,params))))
			||(isNoneFace && this.triggerstart=="alwaysrender")){		 
				this.triggerThis(now);
			if(this.nodetype == 1){
				if(this.looptype=="loopcnt")this.loopcountdown = this.loopcnt;
				for(var j = 0;j<this.childNodesRef.length;j++){
					this.childNodesRef[j].triggerThis(now);
				}
			}
		}
	}
	Mesh.prototype.renderEvent=function(params,now,mat_cam,isNoneFace){
		if(!this.triggered || this.isActive != true)return;
		/*
		if(!isNoneFace){
			if(this.triggerstart=="alwaysrender"||this.name.search("_fg")!=-1)return;
		}else{
			if(this.name.search("_fg")==-1){
				if(this.nodetype==0 && this.triggerstart!="alwaysrender")return;
				if((this.nodetype==2|| this.nodetype==3) && this.rootRef.triggerstart!="alwaysrender")return;
			}
		}
		*/
		if(this.nodetype!=1){//non group root node
			if(this.looptype=="infinite" || (this.frame_id < this.texture_frames.length * this.loopcnt)){
				var idx  = (this.frame_id)%this.texture_frames.length;
				FaceUnity.RenderBillboard(bigtex[this.texture_frames[idx].bigtexidx],this,this.texture_frames[idx],this.matp,this.rotationType?mat_cam:undefined);
			}
			if(this.looptype=="loop1stay"&& this.frame_id >= this.texture_frames.length * this.loopcnt){
				//loop 1 time and stay at last frame.
				var idx  = this.texture_frames.length-1;
				FaceUnity.RenderBillboard(bigtex[this.texture_frames[idx].bigtexidx],this,this.texture_frames[idx],this.matp,this.rotationType?mat_cam:undefined);
			}
		}	
	}
	Mesh.prototype.triggerEndEvent = function(params,now,isNoneFace){
		if(this.triggered!=1)return;
		if(!isNoneFace){
			if(this.triggerend=="newface"){
				this.stop(now);return;
			}
			if(/*action end*/this.triggerend=="faceaction" && isActionTriggered(this.endaction,params)){
				this.stop(now);
			}
			if(this.triggerstart=="alwaysrender" || (this.root!=-1 && this.rootRef.triggerstart=="alwaysrender"))return;
			
			if(/*action keep*/this.triggerstart=="faceaction" && this.needkeepfaceaction== 1 && !isActionTriggered(this.startaction,params)){
				this.stop(now);
			}
		}else{
			if((this.nodetype==0||this.nodetype==1) && this.triggerstart!="alwaysrender")return;
			if(this.nodetype==3 && this.rootRef.triggerstart=="newface" && !params.face_count){
				this.rootRef.recursiveStop(now);
				return;
			}
			if((this.nodetype==2||this.nodetype==3) && this.rootRef.triggerstart!="alwaysrender")return;
		}
		
		if(/*loop end*/this.looptype=="loopcnt" && ((this.frame_id +1) >= this.texture_frames.length * this.loopcnt)){
			this.stop(now);
			if(this.nodetype==3){//last node
				var root = this.rootRef;
				if(root.looptype=="loopcnt"){
					root.loopcountdown-=1;
					if(root.loopcountdown > 0){
						for(var j = 0;j<root.childNodesRef.length;j++){
							root.childNodesRef[j].triggerThis(now);
						}
					}else{
						root.recursiveStop(now);
					}
				}
				if(root.looptype=="infinite"){//restart loop
					for(var j = 0;j<root.childNodesRef.length;j++){
						root.childNodesRef[j].triggerThis(now);
					}
				}
			}else if(this.nodetype==2){
				//start next node
				for(var j = 0;j<this.childNodes.length;j++){
					this.childNodesRef[j].triggerThis(now);
				}
			}
		}
	}
	/////////////////////////////////////reorginize data
	var last_state=0;
	var meshlst = new Array();//oop mesh list for render
	for(var i = 0;i<boards.length;i++){
		var nmesh = new Mesh(boards[i]);
		meshlst.push(nmesh);
		meshlst[nmesh.name]=nmesh;
		if(nmesh.name.search("_fc")!=-1 || nmesh.name.search("_fg")!=-1||nmesh.name.search("_bgseg")!=-1){
			var origin_name = nmesh.name.substr(0,nmesh.name.lastIndexOf('_'));
			meshlst[origin_name]=nmesh
		}
		
	}
	//speed up for focal_length change, copy lst for reExtract
	var reextract_mesh_ref_lst = meshlst.filter(function pred(mesh){
		return mesh.name.search("_fc")!=-1 || mesh.name.search("_fg")!=-1;
	});
	//speed up for orientationChange, copy lst for full screen obj
	var fc_mesh_ref_lst = reextract_mesh_ref_lst.filter(function pred(mesh){
		return mesh.name.search("_fc")!=-1;
	});
	//speed up for background segmentation
	var bgseg_mesh_ref_lst = meshlst.filter(function pred(mesh){
		return mesh.name.search("_bgseg")!=-1;
	});
	var non_bgseg_mesh_ref_lst = meshlst.filter(function pred(mesh){
		return mesh.name.search("_bgseg")==-1;
	});
	//redirect index
	for(var i = 0;i<meshlst.length;i++){
		var nmesh = meshlst[i];
		if(nmesh.root!=-1)nmesh.rootRef=meshlst[nmesh.root];
		if(nmesh.childNodes.length!=0)nmesh.childNodesRef = new Array();
		for(var j = 0;j<nmesh.childNodes.length;j++){
			nmesh.childNodesRef.push(meshlst[nmesh.childNodes[j]]);
		}
	}
	var alwaysrender_mesh_ref_lst = meshlst.filter(function pred(mesh){
		return (mesh.nodetype==0 && mesh.triggerstart=="alwaysrender")||
				((mesh.nodetype==2|| mesh.nodetype==3) && mesh.rootRef.triggerstart=="alwaysrender");
	});
	//part may involve with 3d meshs
	var calTriggerNextNodesRef=function(meshlst_3d){
		for(var i = 0;i<meshlst.length;i++){
			var nmesh = meshlst[i];
			if(nmesh.triggerNextNodes.length!=0)nmesh.triggerNextNodesRef = new Array();
			for(var j = 0;j<nmesh.triggerNextNodes.length;j++){
				var mesh2dref = meshlst[nmesh.triggerNextNodes[j]];
				if(mesh2dref){nmesh.triggerNextNodesRef.push(mesh2dref);}
				else if(meshlst_3d){
					var mesh3dref = meshlst_3d[nmesh.triggerNextNodes[j]];
					if(mesh3dref){nmesh.triggerNextNodesRef.push(mesh3dref);}
				}
			}
		}
	}
	////////////////////////////////////
	console.log("nama platform:",FaceUnity.m_platform);
	if(FaceUnity.m_platform && FaceUnity.m_platform=="android"){
		g_params.isAndroid=1;
	}
	////////////////////////////////////
	return {
		CalRef:calTriggerNextNodesRef,
		meshlst:meshlst,
		SetParam:function(name,value){
			if(g_params[name]!=undefined&&typeof(g_params[name])==typeof(value)){
				if(name=="isLandscape"){
					g_params[name]=value;
					fc_mesh_ref_lst.forEach(function(mesh){mesh.orientationChange();});//notify full screen object
				}
				if(name=="isAndroid"){
					g_params[name]=value;
				}
				if(name=="rotationAngle"){
					if(Math.abs(value-0) < 0.01){
						g_params["matp"] = [1,0,0,1];
					}else if(Math.abs(value-90) < 0.01){
						g_params["matp"] = [0,1,-1,0];
					}else if(Math.abs(value-180) < 0.01){
						g_params["matp"] = [-1,0,0,-1];
					}else if(Math.abs(value-270) < 0.01){
						g_params["matp"] = [0,-1,1,0];
					}else return;
					g_params.hasmatp = 1;
					g_params["rotationAngle"] = value;
				}
				if(name=="rotationTexAngle"){
					g_params["rotationTexAngle"] = value;
				}
				if(name=="orientation"){
					g_params.rmode = value;
				}
				return 1;
			}else{
				try{
					var desc=JSON.parse(name)||{};
					if(desc.name=="@ALL"){
						meshlst.forEach(function(mesh){mesh[desc.param]=value;});
						return 1;
					}
					var mesh=meshlst[desc.name];
					if(!mesh){
						console.log("2d mesh not found");
						return undefined;
					}
					mesh[desc.param]=value;
					return 1;
				}catch(err){console.log(err);}
			}
		},
		////////////////////////////////
		/*back#2ground_seg
		m_texid:0,
		m_matrix:undefined,
		enable_trackerless:1,
		OnGeneralExtraDetector:function(){try{
			//we first compute the letterboxing / rotation matrix
			var matrix=new Float32Array(6);
			var rotation_mode=FaceUnity.g_current_rmode;
			if (cur_rotation_mode == -1 || cur_rotation_mode!=rotation_mode)
			{
				cur_rotation_mode=rotation_mode;
				cnn_prob.length=0;
			}
			//console.log("rotation_mode: ",rotation_mode);
			var w=FaceUnity.g_image_w;
			var h=FaceUnity.g_image_h;
			var dw_letterbox,dh_letterbox;
			if(!(rotation_mode&1)){
				var conceptual_h_letterboxed=Math.max(w/0.5625,h);
				var conceptual_w_letterboxed=conceptual_h_letterboxed*0.5625;
				dw_letterbox=(conceptual_w_letterboxed-w);
				dh_letterbox=(conceptual_h_letterboxed-h);
			}else{
				var conceptual_h_letterboxed=Math.max(h/0.5625,w);
				var conceptual_w_letterboxed=conceptual_h_letterboxed*0.5625;
				dw_letterbox=(conceptual_h_letterboxed-w);
				dh_letterbox=(conceptual_w_letterboxed-h);
			}
			switch(rotation_mode){
				default:{console.log('invalid rotation mode',rotation_mode);}break;
				case 0:{matrix[0]=w;matrix[1]=0;matrix[2]=0;matrix[3]=h;matrix[4]=0;matrix[5]=0;}break;
				case 1:{matrix[0]=0;matrix[1]=h;matrix[2]=-w;matrix[3]=0;matrix[4]=w;matrix[5]=0;}break;
				case 2:{matrix[0]=-w;matrix[1]=0;matrix[2]=0;matrix[3]=-h;matrix[4]=w;matrix[5]=h}break;
				case 3:{matrix[0]=0;matrix[1]=-h;matrix[2]=w;matrix[3]=0;matrix[4]=0;matrix[5]=h;}
			}
			//console.log("w/h"+1.*w/h);
			//console.log("rotation mode: "+rotation_mode);
			//console.log("w/h<1: "+w/h<1);
			if ((rotation_mode&1)^(w/h<1))
			{
				var input_v=FaceUnity.ExtractNNModelInput(model_v.w,model_v.h,model_v.channels, matrix,base_color);
				var output_v=FaceUnity.RunNNModelRaw(model_v,input_v);
				this.m_texid=FaceUnity.UploadBackgroundSegmentationResult(model_v,output_v);
				//console.log("vertical");
				cnn_running_time_sum+=output_v[output_v.length-1];
				cnn_running_time_count++;
				//console.log("average running time:"+cnn_running_time_sum/cnn_running_time_count+"ms");
				if (cnn_prob.length==0){
					for(var i=0;i<output_v.length;i++){cnn_prob[i] = output_v[i];}
				}
				else{
					for(var i=0;i<output_v.length;i++){cnn_prob[i] = 0.5*output_v[i]+0.5*cnn_prob[i]; output_v[i]=cnn_prob[i];}
				}
			}
			else
			{
				var input_h=FaceUnity.ExtractNNModelInput(model_h.w,model_h.h,model_h.channels, matrix,base_color);
				var output_h=FaceUnity.RunNNModelRaw(model_h,input_h);
				this.m_texid=FaceUnity.UploadBackgroundSegmentationResult(model_h,output_h);
				//console.log("horizontal");
				cnn_running_time_sum+=output_h[output_h.length-1];
				cnn_running_time_count++;
				//console.log("average running time:"+cnn_running_time_sum/cnn_running_time_count+"ms");
				if (cnn_prob.length==0){
					for(var i=0;i<output_h.length;i++){cnn_prob[i] = output_h[i];}
				}
				else{
					for(var i=0;i<output_h.length;i++){cnn_prob[i] = 0.5*output_h[i]+0.5*cnn_prob[i]; output_h[i]=cnn_prob[i];}
				}
			}
			
			this.m_matrix=matrix;
		}catch(err){
			console.log(err.stack);
		}},
		FilterEntireImage:function(){try{
			//console.log('FilterEntireImage',this.m_texid)
			if(!this.m_texid){return;}
			now = Date.now();
			var rsq01=1.0/(this.m_matrix[0]*this.m_matrix[0]+this.m_matrix[1]*this.m_matrix[1]);
			var rsq23=1.0/(this.m_matrix[2]*this.m_matrix[2]+this.m_matrix[3]*this.m_matrix[3]);
			for(var i=0;i<bgseg_mesh_ref_lst.length;i++){
				var curbg = bgseg_mesh_ref_lst[i];
				if(curbg.triggered && curbg.isActive){
					elapse = now - curbg.last;
					curbg.frame_id = parseInt(elapse * curbg.fps / 1000);
					if(curbg.force_frame_id!=undefined && curbg.force_frame_id>=0)curbg.frame_id = curbg.force_frame_id;
					var idx  = (curbg.frame_id)%curbg.texture_frames.length;
					FaceUnity.InsertImageFilter("color",s_visualize_shader,{
						inv_matrix0123:[this.m_matrix[0]*rsq01,this.m_matrix[1]*rsq01,this.m_matrix[2]*rsq23,this.m_matrix[3]*rsq23],
						inv_matrix45_image_dim:[this.m_matrix[4],this.m_matrix[5],FaceUnity.g_image_w,FaceUnity.g_image_h],
						tex_segmentation:this.m_texid,
						tex_background:bigtex[curbg.texture_frames[idx].bigtexidx],
						background_uv_lt:curbg.texture_frames[idx].vt.slice(0,4),
						background_uv_rb:curbg.texture_frames[idx].vt.slice(4)
					});	
				}
			}
		}catch(err){
			console.log(err.stack);
		}},
		//back#2ground_seg*/
		////////////////////////////////
		Render:function(params){
			
			try{
				g_params.isTracked = 1;
				now = Date.now();
				for(var i=0;i<arTex.length;i++){/*for ar mesh*/ FaceUnity.RenderAR(arTex[i]);}
				var mat_cam=FaceUnity.CreateViewMatrix([0,0,0,1],params.translation);
				if(last_state==0){
					for(var i = 0; i < meshlst.length; i++)meshlst[i].switchState(last_state,1);
					last_state = 1;
				}
				for(var i = 0; i < meshlst.length; i++){
					meshlst[i].updateEvent(params,now);
					meshlst[i].triggerStartEvent(params,now,false);
				}
				for(var i = 0; i < non_bgseg_mesh_ref_lst.length; i++)non_bgseg_mesh_ref_lst[i].renderEvent(params,now,mat_cam,false);
				for(var i = 0; i < meshlst.length; i++)meshlst[i].triggerEndEvent(params,now,false);
			}catch(err){
				console.log(err.stack)
			}
		},
		
		RenderNonFace:function(params){
			try{
				now = Date.now();
				
				for(var i = 0; i < reextract_mesh_ref_lst.length; i++)reextract_mesh_ref_lst[i].reExtract(params);
				
				if(last_state==1 && !params.face_count){
					for(var i = 0; i < meshlst.length; i++)meshlst[i].switchState(last_state,0);
					last_state = 0;
				}
				
				for(var i = 0; i < meshlst.length; i++){
					meshlst[i].updateEvent(params,now);
					meshlst[i].triggerStartEvent(params,now,true);
				}
				
				if(!params.face_count)for(var i = 0; i < alwaysrender_mesh_ref_lst.length; i++)alwaysrender_mesh_ref_lst[i].renderEvent(params,now,undefined,true);
				for(var i = 0; i < meshlst.length; i++)meshlst[i].triggerEndEvent(params,now,true);
				
				g_params.isReExtractAtRender = 0;
			}catch(err){
				console.log(err.stack)
			}
		},
		name:"example_3D_fueditor_4_0_0_beta",
	};
})()