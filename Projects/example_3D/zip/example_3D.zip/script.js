(function(){
	var g_items = [];
	var item2ds;
	var item3ds;
	const require=function(fn){
		var jsstr = FaceUnity.ReadFromCurrentItem(fn);
		if(jsstr == undefined){
			console.log(fn,"is not exist");
			return undefined;
		}
		console.log("eval",fn,'begin');
		return eval(jsstr);
	};
	var itemname = "dummy";
	try{
		item2ds=require("2d_script.js");
		item3ds=require("3d_script.js");
		if(item3ds!=undefined){
			g_items.push(item3ds);
			itemname = item3ds.name;
		}
		if(item2ds!=undefined){
			g_items.push(item2ds);
			itemname = item2ds.name;
		}
		if(item2ds && item2ds.CalRef)item2ds.CalRef(item3ds.meshlst);
		if(item3ds && item3ds.CalRef)item3ds.CalRef(item2ds.meshlst);
	}catch(err){
		console.log(err.stack);
	}
	console.log("itemname",itemname);
	return {
		SetParam:function(name,value){
			try{
				var respone = false;
				for(var i in g_items){
					var ret = g_items[i].SetParam(name,value);
					if(ret!=undefined)respone=true;
				}
				if(respone)return 1;
				return undefined;
			}catch(err){
				console.log(err.stack);
				return undefined;
			}
		},
		GetParam:function(name){
			for(var i in g_items){
				var ret = g_items[i].GetParam(name);
				if(ret!=undefined)return ret;
			}
			return undefined;
		},
		OnGeneralExtraDetector:function(){
			if(item2ds.OnGeneralExtraDetector)item2ds.OnGeneralExtraDetector();
		},
		FilterEntireImage:function(){
			if(item2ds.FilterEntireImage)item2ds.FilterEntireImage();
		},
		Render:function(params){
			try{
				for(var i in g_items)g_items[i].Render(params);
			}catch(err){
				console.log(err.stack);
			}
		},
		RenderNonFace:function(params){
			for(var i in g_items)g_items[i].RenderNonFace(params);
		},
		name:itemname,
	};
})()